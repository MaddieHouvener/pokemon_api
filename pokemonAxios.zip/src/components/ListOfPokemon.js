import React, {useState} from 'react';

const ListOfPokemon = ({pressButton, props}) => {

    const [pokemon, setPokemon] = useState([])



    return(
        <div>
            <button onClick={pressButton}>Fetch Pokemon</button>
            {/* {pokemon.map((pokemon, idx) => 
                (<div pokemon={pokemon} idx={idx}  key={idx}><li>{pokemon.name}</li></div>))}    */}
        
        
        </div>
    )
}





export default ListOfPokemon;
